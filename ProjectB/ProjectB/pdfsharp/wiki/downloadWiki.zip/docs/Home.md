**Project Description**

This project contains:

**PDFsharp** - A .NET library for processing PDF
&
**MigraDoc Foundation** - Creating documents on the fly


Project homepage: [http://www.pdfsharp.net/](http://www.pdfsharp.net/) 

More details and documented sample code can be found here:

Wiki [http://www.pdfsharp.net/wiki/](http://www.pdfsharp.net/wiki/)


CodePlex is shutting down. You can find PDFsharp and MigraDoc on GitHub:  
[https://github.com/empira/PDFsharp/](https://github.com/empira/PDFsharp/)  
[https://github.com/empira/MigraDoc/](https://github.com/empira/MigraDoc/)

And you can find PDFsharp on SourceForge:  
[https://sourceforge.net/projects/pdfsharp/files/pdfsharp/](https://sourceforge.net/projects/pdfsharp/files/pdfsharp/)

**Sponsors**
![Powered by NDepend](Home_http://download.codeplex.com/download?ProjectName=pdfsharp&DownloadId=151787|http://www.NDepend.com)
NDepend is a Visual Studio tool to manage complex .NET code and achieve high Code Quality
